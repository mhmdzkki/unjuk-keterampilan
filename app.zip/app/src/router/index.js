import { createRouter, createWebHistory } from 'vue-router'
import Dashboard from '../page/Dashboard.vue'
import Home from '../components/Home.vue'
import Create from '../components/Create.vue'

const router = createRouter({
  history: createWebHistory(),
  routes : [
    {
      name: 'Dashboard',
      path: '/',
      component: Dashboard,
      children: [
        {
         name: 'home',
         path: '/home',
         component:Home
       },
       {
         name: 'create',
         path: '/create',
         component:Create
       }
     ]
    },
       
  ]
})

export default router
// module.exports = r