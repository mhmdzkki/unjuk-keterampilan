<template>
    <div>
      <h3 class="text-2xl font-bold text-left py-2">Create Page</h3>
    </div>
  </template>
  
<script setup>
</script>