const data = [
    {"name":"Apple MacBook Pro 17","color":"silver","price":2000,"category":"laptop"}
]
export default data